# Log Model
class Log:

    def __init__(self, type, message, occured_at):
        self.type = type
        self.message = message
        self.occured_at = occured_at